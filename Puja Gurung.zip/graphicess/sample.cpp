#include <stdio.h>
#include <stdlib.h>

void drawLine(int x1, int y1, int x2, int y2);

int main() {
    int x1, y1, x2, y2;

    // Input the coordinates of the line
    printf("Enter the starting point (x1 y1): ");
    scanf("%d %d", &x1, &y1);

    printf("Enter the ending point (x2 y2): ");
    scanf("%d %d", &x2, &y2);

    // Draw the line
    drawLine(x1, y1, x2, y2);

    return 0;
}

void drawLine(int x1, int y1, int x2, int y2) {
    int dx = abs(x2 - x1);
    int dy = abs(y2 - y1);
    int x, y;

    // Determine the direction of the line
    int xInc = (x1 < x2) ? 1 : -1;
    int yInc = (y1 < y2) ? 1 : -1;

    // Initialize decision parameters for the first pixel
    int decision = 2 * dy - dx;

    // Draw the first pixel
    printf("(%d, %d)\n", x1, y1);

    // Loop through all the pixels along the line
    for (x = x1, y = y1; x != x2 || y != y2;) {
        // Increment x and y
        x += xInc;
        y += yInc;

        // Print the current pixel
        printf("(%d, %d)\n", x, y);

        // Update decision parameter
        if (decision > 0) {
            decision -= 2 * dx;
        } else {
            decision += 2 * dy;
        }
    }
}

