#include <stdio.h>
#include <stdlib.h>

void drawLineDDA(int x1, int y1, int x2, int y2);

int main() {
    int x1, y1, x2, y2;

    // Input the coordinates of the line
    printf("Enter the starting point (x1 y1): ");
    scanf("%d %d", &x1, &y1);

    printf("Enter the ending point (x2 y2): ");
    scanf("%d %d", &x2, &y2);

    // Draw the line using DDA algorithm
    drawLineDDA(x1, y1, x2, y2);

    return 0;
}

void drawLineDDA(int x1, int y1, int x2, int y2) {
    int dx = x2 - x1;
    int dy = y2 - y1;
    int steps;

    // Determine the number of steps
    if (abs(dx) > abs(dy)) {
        steps = abs(dx);
    } else {
        steps = abs(dy);
    }

    // Calculate increment values
    float xInc = (float)dx / steps;
    float yInc = (float)dy / steps;

    // Initial coordinates
    float x = x1;
    float y = y1;

    // Print the initial point
    printf("(%d, %d)\n", (int)x, (int)y);

    // Iterate through each step and print the coordinates
    for (int i = 1; i <= steps; i++) {
        x += xInc;
        y += yInc;

        // Print the current pixel
        printf("(%d, %d)\n", (int)x, (int)y);
    }
}

